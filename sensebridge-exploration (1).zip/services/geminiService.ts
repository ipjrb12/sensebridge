import { GoogleGenAI } from "@google/genai";
import { ExplorationAnalysisResult, MotionData, AudioTranscriptionResult, QueryResult } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

/**
 * Transcribes audio using Gemini 2.5 Flash
 */
export const transcribeAudio = async (base64Audio: string): Promise<AudioTranscriptionResult> => {
  try {
    const systemPrompt = "Transcribe this audio. Return JSON: { 'transcript': 'string', 'confidence': number } only.";
    
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: {
        parts: [
          {
            inlineData: {
              mimeType: 'audio/mp3',
              data: base64Audio
            }
          },
          { text: systemPrompt }
        ]
      },
      config: {
        responseMimeType: 'application/json',
      }
    });

    const text = response.text;
    if (!text) throw new Error("No transcription response");
    
    return JSON.parse(text) as AudioTranscriptionResult;
  } catch (error) {
    console.error("Transcription error:", error);
    return { transcript: "(Transcription Failed)", confidence: 0 };
  }
};

/**
 * Analyzes environment for exploration insights using Gemini 3 Pro Preview
 */
export const analyzeEnvironment = async (
  base64Image: string | null,
  audioTranscript: string | null,
  motionData: MotionData
): Promise<ExplorationAnalysisResult> => {
  const systemPrompt = `You are SenseBridge, a multimodal exploration intelligence system. Your purpose is to interpret unfamiliar environments using:

- camera imagery (Visual),
- environmental audio (Acoustic),
- motion sensor data (Physical Stability).

Your tasks:
1. Analyze the visible environment:
   - terrain type and structural features
   - geological/botanical clues
   - water presence indicators
   - navigation hints

2. Analyze audio:
   - echo profile, wildlife signatures, wind resonance.

3. Estimate Geo-Location:
   - Attempt to identify the specific real-world location (country, region, city, or landmark) based on visual clues (architecture, vegetation, signage, plug types, road markings) and audio clues (language, accent, ambient sounds).
   - If specific location is impossible, provide a highly educated guess on the Biome or Region (e.g., "High-altitude Andes", "Urban Tokyo Backalley", "Pacific Northwest Forest").

4. Assess Solo Traveler Safety:
   - Evaluate risks specifically for a lone explorer (isolation, crime risk implied by environment, structural stability, predators).
   - Assign a Safety Score from 0 (Immediate Mortal Danger) to 100 (Perfectly Safe).
   - Provide specific advice for a solo traveler.

5. Infer Microclimate:
   - Estimate light levels, temperature, and humidity.

6. Combine all findings into a unified exploration insight.

Return STRICT JSON:

{
  "environment_type": "string",
  "location_estimation": "string",
  "terrain_summary": "string",
  "structural_notes": "string",
  "bio_clues": ["string"],
  "acoustic_clues": ["string"],
  "microclimate_notes": "string",
  "navigation_hint": "string",
  "visual_findings": ["string"],
  "motion_findings": ["string"],
  "recommended_actions": ["string"],
  "solo_traveler_advice": "string",
  "safety_score": number,
  "confidence": number
}`;

  const parts: any[] = [];
  
  if (base64Image) {
    parts.push({
      inlineData: {
        mimeType: 'image/jpeg',
        data: base64Image
      }
    });
  } else {
    parts.push({ text: "[NO CAMERA IMAGE PROVIDED]" });
  }

  const userMessage = `
    Audio Transcript: ${audioTranscript || "None"}
    Motion Data: ${JSON.stringify(motionData)}
  `;
  parts.push({ text: userMessage });

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-pro-preview',
      contents: {
        role: 'user',
        parts: parts
      },
      config: {
        systemInstruction: systemPrompt,
        responseMimeType: 'application/json',
        temperature: 0.4,
      }
    });

    const text = response.text;
    if (!text) throw new Error("No analysis generated");

    return JSON.parse(text) as ExplorationAnalysisResult;
  } catch (error) {
    console.error("Analysis error:", error);
    throw error;
  }
};

/**
 * Asks a question about the current analyzed environment
 */
export const askSenseBridge = async (
  query: string,
  context: ExplorationAnalysisResult
): Promise<QueryResult> => {
  const systemPrompt = `You are an expert Exploration Guide. 
  Answer the user's question about the environment based ONLY on the provided analysis context.
  Be concise, helpful, and safety-conscious.
  
  Return STRICT JSON:
  {
    "answer": "string",
    "reasoning": "string",
    "confidence": number
  }
  `;

  const userMessage = `
    Context Analysis: ${JSON.stringify(context)}
    
    User Query: "${query}"
  `;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-pro-preview',
      contents: {
        role: 'user',
        parts: [{ text: userMessage }]
      },
      config: {
        systemInstruction: systemPrompt,
        responseMimeType: 'application/json',
      }
    });

    const text = response.text;
    if (!text) throw new Error("No answer generated");
    return JSON.parse(text) as QueryResult;
  } catch (error) {
    console.error("Query error:", error);
    return { 
      answer: "I couldn't process that query right now.", 
      reasoning: "API Error or Timeout", 
      confidence: 0 
    };
  }
};