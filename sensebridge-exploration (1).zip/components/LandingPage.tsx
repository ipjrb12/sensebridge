import React, { useEffect, useRef, useState } from 'react';
import { Icons } from './Icon';

interface LandingPageProps {
  onLaunch: () => void;
}

// Custom SenseBridge Logo Component
const Logo: React.FC = () => (
  <div className="relative w-10 h-10 group">
    <div className="absolute inset-0 bg-emerald-500/30 rounded-xl blur-md group-hover:blur-lg transition-all duration-500"></div>
    <div className="relative w-full h-full bg-gradient-to-br from-slate-800 to-slate-950 border border-slate-700 rounded-xl flex items-center justify-center shadow-2xl overflow-hidden">
      <div className="absolute inset-0 bg-[linear-gradient(45deg,transparent_25%,rgba(16,185,129,0.1)_50%,transparent_75%)] bg-[length:250%_250%,100%_100%] animate-[shimmer_3s_infinite]"></div>
      <svg className="w-6 h-6 text-emerald-400 z-10" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
        <path d="M2 12c0-3.5 3-6.5 10-6.5s10 3 10 6.5" className="opacity-80" />
        <path d="M12 5.5v13" className="text-emerald-500" strokeWidth="2.5" />
        <path d="M12 12m-2 0a2 2 0 1 0 4 0a2 2 0 1 0 -4 0" className="fill-emerald-500/20" />
        <path d="M7 16l2.5-1.5" className="opacity-60" />
        <path d="M17 16l-2.5-1.5" className="opacity-60" />
      </svg>
    </div>
  </div>
);

const FadeInSection: React.FC<{ children: React.ReactNode; delay?: string }> = ({ children, delay = '0ms' }) => {
  const [isVisible, setVisible] = useState(false);
  const domRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(entries => {
      entries.forEach(entry => setVisible(entry.isIntersecting));
    }, { threshold: 0.1 });

    if (domRef.current) observer.observe(domRef.current);
    return () => observer.disconnect();
  }, []);

  return (
    <div
      ref={domRef}
      className={`transition-all duration-1000 transform ${
        isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'
      }`}
      style={{ transitionDelay: delay }}
    >
      {children}
    </div>
  );
};

export const LandingPage: React.FC<LandingPageProps> = ({ onLaunch }) => {
  const [scrollY, setScrollY] = useState(0);

  useEffect(() => {
    const handleScroll = () => setScrollY(window.scrollY);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <div className="min-h-screen bg-slate-950 text-slate-200 overflow-x-hidden font-sans selection:bg-emerald-500/30">
      
      {/* IMMERSIVE BACKGROUND */}
      <div className="fixed inset-0 z-0">
        {/* Terrain Image - Using a reliable mountain/exploration image */}
        <div 
          className="absolute inset-0 bg-cover bg-center bg-no-repeat opacity-40 mix-blend-luminosity scale-105 transition-transform duration-[2s] ease-out"
          style={{ 
            backgroundImage: `url('https://images.unsplash.com/photo-1519681393784-d120267933ba?q=80&w=2070&auto=format&fit=crop')`,
            transform: `scale(${1 + scrollY * 0.0002}) translateY(${scrollY * 0.1}px)`
          }}
        ></div>
        
        {/* Atmospheric Gradients */}
        <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/90 to-slate-900/60"></div>
        <div className="absolute inset-0 bg-gradient-to-b from-transparent via-slate-950/50 to-slate-950"></div>
        
        {/* Animated Orbs */}
        <div className="absolute top-[-20%] left-[10%] w-[800px] h-[800px] bg-emerald-500/5 rounded-full blur-[120px] mix-blend-screen animate-pulse duration-[8000ms]"></div>
        <div className="absolute bottom-[-10%] right-[-10%] w-[600px] h-[600px] bg-blue-600/5 rounded-full blur-[100px] mix-blend-screen animate-pulse duration-[10000ms]"></div>
      </div>

      {/* NAV */}
      <nav className="fixed top-0 left-0 right-0 z-50 flex items-center justify-between px-6 py-6 max-w-7xl mx-auto transition-all duration-300 backdrop-blur-sm">
        <div className="flex items-center gap-3 group cursor-pointer" onClick={onLaunch}>
          <Logo />
          <span className="text-xl font-bold tracking-tight text-white group-hover:text-emerald-400 transition-colors">SenseBridge</span>
        </div>
        <button 
          onClick={onLaunch}
          className="px-5 py-2 text-sm font-medium text-white bg-white/5 border border-white/10 hover:bg-white/10 hover:border-emerald-500/50 rounded-full transition-all backdrop-blur-md"
        >
          Launch Interface
        </button>
      </nav>

      {/* HERO SECTION */}
      <section className="relative z-10 min-h-screen flex flex-col items-center justify-center text-center px-4 pt-20">
        <FadeInSection>
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 text-xs font-bold uppercase tracking-wider mb-8 backdrop-blur-md shadow-[0_0_20px_rgba(16,185,129,0.1)]">
            <Icons.Sparkles className="w-3 h-3 animate-pulse" />
            <span>Exploration Intelligence v2.1</span>
          </div>
        </FadeInSection>

        <FadeInSection delay="100ms">
          <h1 className="text-5xl md:text-7xl lg:text-8xl font-black tracking-tighter text-white mb-8 max-w-5xl mx-auto leading-[0.95] drop-shadow-2xl">
            See What <br/>
            <span className="bg-clip-text text-transparent bg-gradient-to-r from-emerald-400 via-teal-300 to-blue-500 animate-gradient-x">
              Others Miss
            </span>
          </h1>
        </FadeInSection>

        <FadeInSection delay="200ms">
          <p className="text-lg md:text-xl text-slate-300 max-w-2xl mx-auto mb-12 leading-relaxed drop-shadow-md font-light">
            The world's first multimodal AI survival companion. Decode terrain, estimate location, and assess solo traveler safety in real-time.
          </p>
        </FadeInSection>

        <FadeInSection delay="300ms">
          <div className="flex flex-col md:flex-row items-center gap-6">
            <button 
              onClick={onLaunch}
              className="group relative px-8 py-4 bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-lg rounded-full shadow-[0_0_40px_-10px_rgba(16,185,129,0.5)] transition-all hover:scale-105 hover:shadow-[0_0_60px_-10px_rgba(16,185,129,0.6)] flex items-center gap-3 overflow-hidden"
            >
              <span className="relative z-10">Initialize System</span>
              <Icons.ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform relative z-10" />
              <div className="absolute inset-0 bg-gradient-to-r from-emerald-500 to-teal-400 opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>
            </button>
            <button onClick={() => window.scrollTo({ top: window.innerHeight, behavior: 'smooth' })} className="text-sm font-medium text-slate-400 hover:text-white transition-colors flex items-center gap-2">
              Explore Features <Icons.ChevronDown className="w-4 h-4" />
            </button>
          </div>
        </FadeInSection>
      </section>

      {/* FEATURES / CAPABILITIES SECTION */}
      <section className="relative z-10 py-32 px-4 bg-slate-950/80 backdrop-blur-xl border-t border-slate-900 shadow-[0_-20px_60px_rgba(0,0,0,0.8)]">
        <div className="max-w-7xl mx-auto">
          <FadeInSection>
            <div className="text-center mb-20">
              <h2 className="text-3xl md:text-5xl font-bold text-white mb-6">Beyond Human Senses</h2>
              <p className="text-slate-400 max-w-2xl mx-auto text-lg">
                SenseBridge extends your awareness into the data layer of reality, providing crucial insights for the solo explorer.
              </p>
            </div>
          </FadeInSection>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {/* Feature 1 */}
            <FadeInSection delay="0ms">
              <div className="p-8 h-full rounded-3xl bg-white/5 border border-white/5 hover:border-emerald-500/30 hover:bg-white/10 transition-all duration-300 group hover:-translate-y-2">
                <div className="w-14 h-14 bg-emerald-500/10 rounded-2xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform border border-emerald-500/20">
                  <Icons.Map className="w-7 h-7 text-emerald-500" />
                </div>
                <h3 className="text-xl font-bold text-slate-100 mb-3">Global Localization</h3>
                <p className="text-slate-400 leading-relaxed text-sm">
                  Instantly estimate your real-world location using visual landmarks, flora, and architectural styles.
                </p>
              </div>
            </FadeInSection>

            {/* Feature 2 */}
            <FadeInSection delay="100ms">
              <div className="p-8 h-full rounded-3xl bg-white/5 border border-white/5 hover:border-blue-500/30 hover:bg-white/10 transition-all duration-300 group hover:-translate-y-2">
                <div className="w-14 h-14 bg-blue-500/10 rounded-2xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform border border-blue-500/20">
                  <Icons.ShieldCheck className="w-7 h-7 text-blue-500" />
                </div>
                <h3 className="text-xl font-bold text-slate-100 mb-3">Solo Traveler Guard</h3>
                <p className="text-slate-400 leading-relaxed text-sm">
                  Real-time safety scoring and specific advice for lone explorers based on environmental risks.
                </p>
              </div>
            </FadeInSection>

            {/* Feature 3 */}
            <FadeInSection delay="200ms">
              <div className="p-8 h-full rounded-3xl bg-white/5 border border-white/5 hover:border-purple-500/30 hover:bg-white/10 transition-all duration-300 group hover:-translate-y-2">
                <div className="w-14 h-14 bg-purple-500/10 rounded-2xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform border border-purple-500/20">
                  <Icons.Brain className="w-7 h-7 text-purple-500" />
                </div>
                <h3 className="text-xl font-bold text-slate-100 mb-3">Multimodal Reasoning</h3>
                <p className="text-slate-400 leading-relaxed text-sm">
                  Fuses sight, sound, and motion data to detect hazards invisible to a single sense.
                </p>
              </div>
            </FadeInSection>

            {/* Feature 4 */}
            <FadeInSection delay="300ms">
              <div className="p-8 h-full rounded-3xl bg-white/5 border border-white/5 hover:border-orange-500/30 hover:bg-white/10 transition-all duration-300 group hover:-translate-y-2">
                <div className="w-14 h-14 bg-orange-500/10 rounded-2xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform border border-orange-500/20">
                  <Icons.Scan className="w-7 h-7 text-orange-500" />
                </div>
                <h3 className="text-xl font-bold text-slate-100 mb-3">Deep Environment Scan</h3>
                <p className="text-slate-400 leading-relaxed text-sm">
                  Detailed breakdown of microclimates, bio-clues, and structural integrity notes.
                </p>
              </div>
            </FadeInSection>
          </div>
        </div>
      </section>

      {/* LIVE DEMO PREVIEW SECTION */}
      <section className="relative z-10 py-32 px-4 overflow-hidden bg-slate-950">
        <div className="max-w-7xl mx-auto">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-20 items-center">
            
            <FadeInSection>
              <div className="space-y-10">
                <h2 className="text-4xl md:text-5xl font-bold text-white leading-tight">
                  <span className="text-emerald-400">Intelligent Analysis</span><br/>
                  In Your Pocket
                </h2>
                <p className="text-xl text-slate-400 font-light">
                  Whether you're hiking remote peaks or navigating dense urban labyrinths, SenseBridge provides the data you need to move with confidence.
                </p>
                
                <div className="space-y-6">
                  <div className="flex items-start gap-4">
                    <div className="p-3 rounded-lg bg-emerald-500/10 border border-emerald-500/20 mt-1">
                      <Icons.Map className="w-6 h-6 text-emerald-400" />
                    </div>
                    <div>
                      <h4 className="text-lg font-bold text-slate-200">Where am I?</h4>
                      <p className="text-slate-500">Auto-triangulation of location based on visual and audio cues.</p>
                    </div>
                  </div>
                  <div className="flex items-start gap-4">
                     <div className="p-3 rounded-lg bg-blue-500/10 border border-blue-500/20 mt-1">
                      <Icons.ShieldCheck className="w-6 h-6 text-blue-400" />
                    </div>
                    <div>
                      <h4 className="text-lg font-bold text-slate-200">Am I Safe?</h4>
                      <p className="text-slate-500">Instant safety scoring (0-100) for solo travelers.</p>
                    </div>
                  </div>
                </div>
                
                <button 
                  onClick={onLaunch}
                  className="mt-8 px-8 py-3 bg-slate-800 hover:bg-slate-700 text-white rounded-full font-medium transition-colors flex items-center gap-2 border border-slate-700"
                >
                  Try the Live Demo <Icons.ArrowRight className="w-4 h-4" />
                </button>
              </div>
            </FadeInSection>

            <FadeInSection delay="200ms">
              <div className="relative group cursor-pointer perspective-1000" onClick={onLaunch}>
                <div className="absolute -inset-1 bg-gradient-to-r from-emerald-600 to-blue-600 rounded-3xl blur opacity-25 group-hover:opacity-60 transition duration-1000 group-hover:duration-200"></div>
                <div className="relative bg-slate-900/90 border border-slate-800 rounded-3xl p-6 shadow-2xl overflow-hidden transform group-hover:rotate-y-2 group-hover:rotate-x-2 transition-transform duration-500">
                  
                  {/* Mock Interface UI - Updated to match App.tsx features */}
                  <div className="flex items-center justify-between border-b border-slate-800 pb-4 mb-4">
                    <div className="flex items-center gap-2">
                       <div className="w-3 h-3 rounded-full bg-red-500"></div>
                       <div className="w-3 h-3 rounded-full bg-yellow-500"></div>
                       <div className="w-3 h-3 rounded-full bg-green-500"></div>
                    </div>
                    <div className="text-xs font-mono text-emerald-500 animate-pulse">● SYSTEM_ONLINE</div>
                  </div>

                  <div className="space-y-4">
                    <div className="aspect-video bg-slate-950 rounded-xl flex items-center justify-center border border-slate-800 relative overflow-hidden group-hover:border-emerald-500/30 transition-colors">
                      {/* Using a specific jungle/ruin image for the demo tile */}
                      <div className="absolute inset-0 bg-[url('https://images.unsplash.com/photo-1596394516093-501ba68a0ba6?q=80&w=800&auto=format&fit=crop')] bg-cover bg-center opacity-70 mix-blend-normal"></div>
                      <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/20 to-transparent"></div>
                      
                      {/* Scanning Line */}
                      <div className="absolute top-0 left-0 right-0 h-[2px] bg-emerald-500 shadow-[0_0_20px_rgba(16,185,129,0.8)] animate-[scan_3s_linear_infinite]"></div>

                      <div className="absolute top-4 right-4">
                         <div className="flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-500/20 border border-emerald-500/30 backdrop-blur-md">
                            <Icons.ShieldCheck className="w-3 h-3 text-emerald-400" />
                            <span className="text-xs font-bold text-emerald-400">SAFE (88/100)</span>
                         </div>
                      </div>

                      <div className="absolute bottom-4 left-4 right-4">
                        <div className="flex items-center gap-2 text-emerald-400 mb-1">
                          <Icons.Map className="w-3 h-3" />
                          <span className="text-xs font-bold uppercase tracking-wider shadow-black drop-shadow-md">Angkor Wat, Cambodia</span>
                        </div>
                        <div className="inline-block px-3 py-1 bg-black/60 backdrop-blur-md text-slate-200 text-xs font-mono border border-slate-700 rounded-lg">
                           Structure: 12th Century Sandstone
                        </div>
                      </div>
                    </div>
                    
                    {/* Mock Analysis Text */}
                    <div className="space-y-3">
                       <div className="flex items-start gap-3 p-3 bg-emerald-900/10 border border-emerald-500/20 rounded-lg">
                          <Icons.Brain className="w-4 h-4 text-emerald-500 mt-0.5" />
                          <div>
                            <div className="text-xs text-emerald-400 font-bold mb-0.5">SOLO TRAVELER ADVICE</div>
                            <div className="text-xs text-slate-300 leading-relaxed">"Well-trafficked tourist area. Structure is stable, but watch for slippery moss on north-facing steps. Safe for solo entry."</div>
                          </div>
                       </div>
                       
                       <div className="flex gap-2">
                          <div className="h-1.5 bg-slate-800 rounded animate-pulse w-1/3"></div>
                          <div className="h-1.5 bg-slate-800 rounded animate-pulse w-1/3"></div>
                       </div>
                    </div>
                  </div>

                  {/* Hover Overlay */}
                  <div className="absolute inset-0 flex items-center justify-center bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity backdrop-blur-[2px]">
                    <div className="bg-white text-slate-900 px-6 py-3 rounded-full font-bold flex items-center gap-2 transform translate-y-4 group-hover:translate-y-0 transition-transform shadow-xl">
                      Launch Interface <Icons.ArrowRight className="w-4 h-4"/>
                    </div>
                  </div>

                </div>
              </div>
            </FadeInSection>

          </div>
        </div>
      </section>

      {/* FINAL CTA */}
      <section className="relative z-10 py-32 px-4 text-center overflow-hidden">
        {/* Abstract Background for CTA */}
        <div className="absolute inset-0 bg-emerald-900/20"></div>
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-slate-900/0 via-slate-950 to-slate-950"></div>
        
        <FadeInSection>
          <div className="relative z-10">
            <h2 className="text-4xl md:text-6xl font-bold text-white mb-8 tracking-tight drop-shadow-xl">
              Ready to explore?
            </h2>
            <button 
              onClick={onLaunch}
              className="px-10 py-5 bg-white text-slate-900 font-bold text-xl rounded-full shadow-2xl hover:bg-emerald-50 hover:text-emerald-900 transition-all hover:scale-105 flex items-center gap-3 mx-auto"
            >
              Launch SenseBridge <Logo />
            </button>
          </div>
        </FadeInSection>
      </section>

      {/* FOOTER */}
      <footer className="relative z-10 border-t border-white/5 bg-slate-950 py-12 text-center text-slate-500 text-sm">
        <div className="max-w-7xl mx-auto px-4 flex flex-col md:flex-row justify-between items-center gap-4">
          <div className="flex items-center gap-2 opacity-70 hover:opacity-100 transition-opacity">
             <Logo />
             <span className="font-semibold text-slate-300">SenseBridge</span>
             <span className="text-xs px-2 py-0.5 bg-slate-800 rounded-full border border-slate-700">EXPLORATION</span>
          </div>
          <p>© 2025 SenseBridge AI. Built for the intrepid.</p>
        </div>
      </footer>

      {/* Global CSS for Animations */}
      <style>{`
        @keyframes shimmer {
          0% { background-position: 0% 50%; }
          50% { background-position: 100% 50%; }
          100% { background-position: 0% 50%; }
        }
        @keyframes scan {
          0% { top: 0%; opacity: 0; }
          10% { opacity: 1; }
          90% { opacity: 1; }
          100% { top: 100%; opacity: 0; }
        }
        .perspective-1000 {
          perspective: 1000px;
        }
        .rotate-y-2 {
          transform: rotateY(5deg);
        }
      `}</style>

    </div>
  );
};