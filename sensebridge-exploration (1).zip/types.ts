export interface MotionData {
  accel: { x: number; y: number; z: number };
  gyro: { x: number; y: number; z: number };
}

export interface AudioTranscriptionResult {
  transcript: string;
  confidence: number;
}

export interface ExplorationAnalysisResult {
  environment_type: string;
  location_estimation: string;
  terrain_summary: string;
  structural_notes: string;
  bio_clues: string[];
  acoustic_clues: string[];
  microclimate_notes: string;
  navigation_hint: string;
  visual_findings: string[];
  motion_findings: string[];
  recommended_actions: string[];
  solo_traveler_advice: string;
  safety_score: number;
  confidence: number;
}

export interface ExplorationLogEntry extends ExplorationAnalysisResult {
  id: string;
  timestamp: string;
  imageFrameUrl: string | null;
  audioTranscript: string | null;
}

export interface QueryResult {
  answer: string;
  reasoning: string;
  confidence: number;
}